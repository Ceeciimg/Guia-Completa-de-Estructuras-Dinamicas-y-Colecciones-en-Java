package Comparable;

import java.util.*;


public class Persona implements Comparable<Persona> {
    String nombre;
    int edad;

    // Constructor
    public Persona(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    // usa compareTo para ordenar por edad
    @Override
    public int compareTo(Persona otraPersona) {
        return Integer.compare(this.edad, otraPersona.edad);
    }

    @Override
    public String toString() {
        return nombre + " (" + edad + " años)";
    }
}


