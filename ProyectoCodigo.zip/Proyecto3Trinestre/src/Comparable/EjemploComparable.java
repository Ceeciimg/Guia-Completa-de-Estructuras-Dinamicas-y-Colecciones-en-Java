package Comparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EjemploComparable {

    public static void main(String[] args) {

        List<Persona> listaPersonas = new ArrayList<>();

        listaPersonas.add(new Persona("ceci", 20));
        listaPersonas.add(new Persona("ruben", 19));
        listaPersonas.add(new Persona("paloma", 19));

        // Ordenamos usando Comparable (por edad)
        Collections.sort(listaPersonas);

        System.out.println("Lista ordenada por edad: " + listaPersonas);
    }
}

