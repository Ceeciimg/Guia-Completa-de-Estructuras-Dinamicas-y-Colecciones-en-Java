package InterfazIterable;

import java.util.*;


public class MiColeccion implements Iterable<Integer> {

    private List<Integer> lista;

    public MiColeccion() {
        lista = new ArrayList<>();
        lista.add(1);
        lista.add(2);
        lista.add(3);
    }

    // Implementación del método iterator() para hacer el recorrido con for-each
    @Override
    public Iterator<Integer> iterator() {
        return lista.iterator();
    }
}


