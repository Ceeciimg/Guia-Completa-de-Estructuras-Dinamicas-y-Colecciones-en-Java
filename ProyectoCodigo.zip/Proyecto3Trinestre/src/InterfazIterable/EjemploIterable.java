package InterfazIterable;

public class EjemploIterable {

    public static void main(String[] args) {
        MiColeccion coleccion = new MiColeccion();

        // Usamos for-each debido a q se ha implementado iterable
        for (Integer numero : coleccion) {
            System.out.println(numero);
        }
    }
}
