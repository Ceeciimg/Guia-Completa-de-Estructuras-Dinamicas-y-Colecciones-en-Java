package ForvsForeach;

import java.util.*;


public class Ejemplo {


    public static void main(String[] args) {
        List<Integer> lista = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));

        // Usando for tradicional con indices
        for (int i = 0; i < lista.size(); i++) {
            System.out.println("Elemento en índice " + i + ": " + lista.get(i));
        }

        // Usando for-each sin indices
        for (Integer numero : lista) {
            System.out.println("Elemento: " + numero);
        }
    }
}

