package Colecciones;

import java.util.*;


public class Colecciones {


    public static void main(String[] args) {

        // ArrayList
        List<Integer> lista = new ArrayList<>();
        lista.add(10);
        lista.add(20);
        lista.add(30);
        System.out.println("ArrayList: " + lista);  // O(1)

        // LinkedList: eliminar en la posición cero
        List<Integer> listaEnlazada = new LinkedList<>();
        listaEnlazada.add(5);
        listaEnlazada.add(10);
        listaEnlazada.remove(0);  // eliminar
        System.out.println("LinkedList: " + listaEnlazada);  // O(1)

        // HashSet: no mantiene el orden
        Set<Integer> conjunto = new HashSet<>();
        conjunto.add(50);
        conjunto.add(60);
        conjunto.add(70);
        System.out.println("HashSet (sin orden): " + conjunto);

        // TreeSet: ordena automáticamente
        Set<Integer> conjuntoOrdenado = new TreeSet<>();
        conjuntoOrdenado.add(3);
        conjuntoOrdenado.add(1);
        conjuntoOrdenado.add(2);
        System.out.println("TreeSet (ordenado): " + conjuntoOrdenado); // O(log n)


        // PriorityQueue: Ordena por prioridad (el más bajo primero)
        Queue<Integer> colaPrioridad = new PriorityQueue<>();
        colaPrioridad.add(5);
        colaPrioridad.add(1);
        colaPrioridad.add(10);
        System.out.println("PriorityQueue: " + colaPrioridad.poll());
    }
}

