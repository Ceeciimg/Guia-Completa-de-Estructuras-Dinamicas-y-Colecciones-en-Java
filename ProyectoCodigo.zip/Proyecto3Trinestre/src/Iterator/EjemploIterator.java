package Iterator;

    import java.util.*;

    public class EjemploIterator {

        public static void main(String[] args) {
            List<Integer> lista = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));

            // iterador
            Iterator<Integer> iterador = lista.iterator();

            // se usa iterator() para recorrer y eliminar
            while (iterador.hasNext()) {
                Integer numero = iterador.next();
                if (numero == 3) {
                    iterador.remove(); // para eliminar
                }
            }

            System.out.println("Lista después de eliminar el 3: " + lista);
        }
    }

