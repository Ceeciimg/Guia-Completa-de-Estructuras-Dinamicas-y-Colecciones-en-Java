package ColeccionesInmutables;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class ColeccionesInmutables {

    public static void main(String[] args) {

        // Crear una lista inmutable
        List<String> listaInmutable = List.of("Manzana", "platano", "Cereza");

        // Crear un conjunto inmutable
        Set<String> setInmutable = Set.of("Rojo", "Verde", "Azul");

        // Crear un mapa inmutable
        Map<Integer, String> mapaInmutable = Map.of(1, "Uno", 2, "Dos", 3, "Tres");

        // Mostrar las colecciones inmutables
        System.out.println("Lista inmutable: " + listaInmutable);
        System.out.println("Conjunto inmutable: " + setInmutable);
        System.out.println("Mapa inmutable: " + mapaInmutable);

    }

}
