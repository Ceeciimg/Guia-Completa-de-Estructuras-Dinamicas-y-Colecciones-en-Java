package ListIterator;

import java.util.*;


public class EjemploListIterator {

    public static void main(String[] args) {
        // Lista
        List<Integer> lista = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));

        // ListIterator
        ListIterator<Integer> listIterator = lista.listIterator();

        // Recorrer la lista hacia adelante
        while (listIterator.hasNext()) {
            Integer numero = listIterator.next();
            System.out.println("Elemento: " + numero);
        }

        // Modificar el valor 3 por 10
        listIterator = lista.listIterator();
        while (listIterator.hasNext()) {
            Integer numero = listIterator.next();
            if (numero == 3) {
                listIterator.set(10); // se cambia el valor cn un set
            }
        }


        System.out.println("Lista modificada: " + lista);
    }
}
