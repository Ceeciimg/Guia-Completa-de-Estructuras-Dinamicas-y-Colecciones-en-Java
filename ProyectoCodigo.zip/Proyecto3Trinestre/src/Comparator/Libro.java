package Comparator;

import java.util.*;


public class Libro {

    String titulo;
    int anioPublicacion;

    public Libro(String titulo, int anioPublicacion) {
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
    }

    @Override
    public String toString() {
        return titulo + " (" + anioPublicacion + ")";
    }
}

