package Comparator;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class EjemploComparatorLibro {

    public static void main(String[] args) {

        List<Libro> libros = new ArrayList<>();
        libros.add(new Libro("Java", 2020));
        libros.add(new Libro("Avanzado de Java", 2018));
        libros.add(new Libro("Introducción a poo", 2019));

        // comparator ordena por año de publicación
        Comparator<Libro> ordenarPorAnio = (l1, l2) -> Integer.compare(l1.anioPublicacion, l2.anioPublicacion);


        libros.sort(ordenarPorAnio);
        System.out.println("Libros ordenados por año de publicación: " + libros);
    }
}

